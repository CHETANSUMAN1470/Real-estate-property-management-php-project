<?php

require "partials/_dbconnect.php";

$state = $_POST['state'];

$sql = "SELECT * FROM cities WHERE state_id ='$state'";

$result = mysqli_query($conn,$sql);
?> 
<option value="">Select City</option>
<?php
	while ($row = mysqli_fetch_array($result)) {
?>
<option value="<?php echo $row['id'];?>"><?php echo $row['city_name'];?></option>

<?php
		}
?>