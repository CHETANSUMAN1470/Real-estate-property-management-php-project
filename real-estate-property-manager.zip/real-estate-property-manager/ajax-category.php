<?php 
require "partials/_dbconnect.php";

$id = $_POST['id'];
$checked = $_POST['checked'];

if($checked==1){
	$sql = "UPDATE categories SET status='1' WHERE id='$id'";
	$result = mysqli_query($conn,$sql) or die("Query failed.");

	if ($result) {
		echo 1;
	}else{
		echo 0;
	}
}else{
	$sql = "UPDATE categories SET status='0' WHERE id='$id'";
	$result = mysqli_query($conn,$sql) or die("Query failed.");

	if ($result) {
		echo 1;
	}else{
		echo 0;
	}
}