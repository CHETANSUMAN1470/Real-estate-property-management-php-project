<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">

    <title>CSProperty-Real State Property Management</title>

    <style type="text/css">
      .header{
        padding: 10px 0;
      }
      .navbar-brand{
        font-weight: 800;
        font-size: 25px;
      }
      #carouselExampleIndicators{
        margin: 0 50px;
        border-radius: 20px;
        overflow: hidden;
      }
      .btn-top{
        border-radius: 20px;
        padding: 5px 20px;
        background: #e5edff;
        color: #00a7ff;
        border: none;
        margin-bottom: 20px !important;
      }
      .border{
        border-radius: 10px;
      }

      .img-fluid{
        height: 608px !important;
      }
      ul li{
        margin: 0 20px;
      }
      .footer{
        padding: 10px 0 5px 0;
        background-color: #f8f9fa;
      }
      #listing{
        padding: 100px 0;
      }
      #agent{
        padding: 100px 0;
        background-color: #f8f8f8;
      }
      .agent-img{
        border-radius: 50%;
        width: 150px;
        height: 150px;
        margin-top: 20px;
      }
      .card-text{
        font-size: 12px;
      }
      #about{
        padding: 100px 0;
      }
    </style>
  </head>
  <body>
    <div class="header">
      <div class="container">    
        <nav class="navbar navbar-expand-lg navbar-light bg-light py-2">
          <a class="navbar-brand" href="/real-estate-property-manager">CS-Property</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto">
              <li class="nav-item active">
                <a class="nav-link" href="/real-estate-property-manager">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#agent">Agents</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="listing.php">Listing</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#about">About</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#contact">Contact</a>
              </li>
            </ul>
            <div class="mx-2 row">
              <a class="btn btn-outline-dark mr-2" href="signup.php" >SignUp</a> 
              <a class="btn btn-outline-dark mr-2" href="login.php">LogIn</a> 
            </div>
          </div>
        </nav>
      </div>
    </div>

    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
      <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="img/home1.jpg" class="d-block w-100" alt="..." width="100%" height="600px">
        </div>
        <div class="carousel-item">
          <img src="img/home3.jpg" class="d-block w-100" alt="..." width="100%" height="600px">
        </div>
        <div class="carousel-item">
          <img src="img/home2.jpg" class="d-block w-100" alt="..." width="100%" height="600px">
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-target="#carouselExampleIndicators" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-target="#carouselExampleIndicators" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </button>
    </div>

    <section id="listing">
      <div class="container text-center">
        <button class="btn btn-primary mb-2 btn-top">Discover</button>
        <h2 class="mb-3">Popular Listing</h2>
        <p class="mb-4">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>

        <?php require "partials/_sellerdata.php"; ?>
        <a class="btn btn-primary mt-4" href="listing.php"> View More </a>
      </div>
    </section>

    <section id="agent">
      <div class="container text-center">
        <div class="row">
          <div class="col-12 mb-3">
              <button class="btn btn-primary mb-2 btn-top">Our Team</button>
            <h2 class="mb-3">Meet Our Agents</h2>
            <p class="mb-4">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
          </div>
          <div class="col-3">
            <div class="border mx-1" >
              <img src="img/agent.jpg" class="agent-img card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title mb-1">Chetan Suman</h5>
                <p class="card-text text-black-50 mt-0">Company Agent</p>
                <a href="#" class="border px-2 py-1"><i class="bi bi-facebook"></i></a>
                <a href="#" class="border px-2 py-1"><i class="bi bi-instagram"></i></a>
                <a href="#" class="border px-2 py-1"><i class="bi bi-linkedin"></i></a>
                <a href="#" class="border px-2 py-1"><i class="bi bi-behance"></i></a>
              </div>
            </div>
          </div>
          <div class="col-3 text-center">
            <div class="border mx-1" >
              <img src="img/girl.jpg" class="agent-img card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title mb-1">Anil Sharma</h5>
                <p class="card-text text-black-50 mt-0">Company Agent</p>
                <a href="#" class="border px-2 py-1"><i class="bi bi-instagram"></i></a>
                <a href="#" class="border px-2 py-1"><i class="bi bi-facebook"></i></a>
                <a href="#" class="border px-2 py-1"><i class="bi bi-linkedin"></i></a>
                <a href="#" class="border px-2 py-1"><i class="bi bi-behance"></i></a>
              </div>
            </div>
          </div>
          <div class="col-3">
            <div class="border mx-1" >
              <img src="img/chetan.jpg" class="agent-img card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title mb-1">Dheeraj Suman</h5>
                <p class="card-text text-black-50 mt-0">Company Agent</p>
                <a href="#" class="border px-2 py-1"><i class="bi bi-linkedin"></i></a>
                <a href="#" class="border px-2 py-1"><i class="bi bi-facebook"></i></a>
                <a href="#" class="border px-2 py-1"><i class="bi bi-instagram"></i></a>
                <a href="#" class="border px-2 py-1"><i class="bi bi-behance"></i></a>
              </div>
            </div>
          </div>
          <div class="col-3">
            <div class="border mx-1">
              <img src="img/agent2.jpg" class="agent-img card-img-top" alt="...">
              <div class="card-body">
                <h5 class="card-title mb-1">Satya Prakash</h5>
                <p class="card-text  text-black-50 mt-0">Company Agent</p>
                <a href="#" class="border px-2 py-1"><i class="bi bi-behance"></i></a>
                <a href="#" class="border px-2 py-1"><i class="bi bi-facebook"></i></a>
                <a href="#" class="border px-2 py-1"><i class="bi bi-instagram"></i></a>
                <a href="#" class="border px-2 py-1"><i class="bi bi-linkedin"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="about">
      <div class="container">
        <div class="row">
          <div class="col-6 py-5">
            <a class="btn btn-primary mb-3 btn-top">About Us</a>
            <h2 class="mb-3">Homes around the world</h2>
            <p>Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat consequat auctor eu in elit. </p>
            <p class="mb-4">Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor a ornare odi</p>
            <a href="#" class="btn btn-primary mt-4">View For Rent</a>
          </div>
          <div class="col-6">
            <div class="row">
              <div class="col-6 mb-2">
                <img src="img/home1.jpg" width="100%" height="180px">
              </div>
              <div class="col-6 mb-2">
                <img src="img/home2.jpg" width="100%" height="150px">
              </div>
              <div class="col-6">
                <img src="img/home2.jpg" width="100%" height="200px">
              </div>
              <div class="col-6">
                <img src="img/home3.jpg" width="100%" height="200px">
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="footer text-center">
      <p class="text-center mb-0">&copy Copyright; <strong>CS Property.</strong> All Right Reserved. Designed by <a href="#">CHETAN SUMAN</a></p>
    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

  </body>
</html>