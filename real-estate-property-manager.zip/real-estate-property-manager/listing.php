<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">

    <title>CSProperty-Real State Property Management</title>

    <style type="text/css">
      .header{
        padding: 10px 0;
      }
      .navbar-brand{
        font-weight: 800;
        font-size: 25px;
      }
      #carouselExampleIndicators{
        margin: 0 50px;
        border-radius: 20px;
        overflow: hidden;
      }
      .btn-top{
        border-radius: 20px;
        padding: 5px 20px;
        background: #e5edff;
        color: #00a7ff;
        border: none;
        margin-bottom: 20px !important;
      }
      .border{
        border-radius: 10px;
      }

      .img-fluid{
        height: 680px !important;
      }
      ul li{
        margin: 0 20px;
      }
      .footer{
        padding: 10px 0 5px 0;
        background-color: #f8f9fa;
      }
      #listing{
        padding: 100px 0;
      }
      #agent{
        padding: 100px 0;
        background-color: #f8f8f8;
      }
      .agent-img{
        border-radius: 50%;
        width: 150px;
        height: 150px;
        margin-top: 20px;
      }
      .card-text{
        font-size: 12px;
      }
      #about{
        padding: 100px 0;
      }
    </style>
  </head>
  <body>
    <div class="header">
      <div class="container">    
        <nav class="navbar navbar-expand-lg navbar-light bg-light py-2">
          <a class="navbar-brand" href="/real-estate-property-manager">CS-Property</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto">
              <li class="nav-item active">
                <a class="nav-link" href="/real-estate-property-manager">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="./#agent">Agents</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="listing.php">Listing</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="./#about">About</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Contact</a>
              </li>
            </ul>
            <div class="mx-2 row">
              <a class="btn btn-outline-dark mr-2" href="signup.php" >SignUp</a> 
              <a class="btn btn-outline-dark mr-2" href="login.php">LogIn</a> 
            </div>
          </div>
        </nav>
      </div>
    </div>

<section  style="background-color: #f8f8f8;">
    <div class="container my-5 text-center">
      <h2>Our Listings</h2>
      <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>

       <?php
    
          require "partials/_dbconnect.php";

          $sql = "SELECT * FROM `sellertable`";
          $result = mysqli_query($conn , $sql);
          $row = mysqli_num_rows($result);

          ?>

      <div class="row text-left">
      <?php
          if ($row > 0) {
            while($x = mysqli_fetch_assoc($result)) {
              if($x['status'] == 0){
            echo '<div class="card col-4 my-3" style="width: 18rem;">
        <img src="partials/images/'.$x["property_image"].'" class="card-img-top" alt="..." height="200px">
        <div class="card-body">
          <h5 class="card-title">'.$x["property_name"].'</h5>
          <p class="card-text">'.$x["address"].', '.$x["city"].', '.$x["state"].', '.$x["country"].'</p>
          <a href="propertydetails.php?id='.$x["id"].'" class="btn btn-primary">View Details</a>
        </div>
      </div>';
              }
            }
          }
      ?>
</div>
    </div>
  </section>


    <?php require "partials/_footer.php";?>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

  </body>
</html>