-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 18, 2023 at 07:44 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `realstatedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `buyertable`
--

CREATE TABLE `buyertable` (
  `id` int(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `property_name` varchar(50) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp(),
  `owneremail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buyertable`
--

INSERT INTO `buyertable` (`id`, `name`, `mobile`, `email`, `description`, `property_name`, `time`, `owneremail`) VALUES
(1, 'Chetan suman', '8078654959', 'chetansuman1470@gmail.com', 'It is beautiful.', 'Sharmas Villa', '2023-01-20 11:52:23', 'anilsharma1470@gmail.com'),
(2, 'Rajendra ', '9413276451', 'rajendra123@gmail.com', 'Nice', 'Prakash Villa', '2023-01-20 11:53:19', ''),
(3, 'Raju', '7742769229', 'raju123@gmail.com', 'I like this villa.', 'Sharmas Villa', '2023-01-20 13:36:53', ''),
(4, 'Himanshu', '7742769229', 'himanshusaroya1470@gmail.com', 'Nice\r\n', 'Sharmas Villa', '2023-01-20 15:09:48', ''),
(7, 'Rajendra ji', '9413276451', 'raju123@gmail.com', 'srgrdyg', 'Prakash Villa', '2023-01-20 15:28:45', 'satyaprakash1470@gmail.com'),
(8, 'Tannu suman', '8107002376', 'tannusuman1470@gmail.com', 'Attractive', 'Suman Banglow', '2023-01-21 10:16:36', 'balramsuman1470@gmail.com'),
(11, 'Akbar', '6376848186', 'akbar@gmail.com', 'nice', 'Sharma Property', '2023-02-02 10:31:15', 'anilsharma1470@gmail.com'),
(12, 'Mahesh Dhakad', '8107002376', 'maheshdhakad1470@gmail.com', 'fjheliurgrgwijwiofhifydskjfsdkfgd', 'Suman Banglow', '2023-02-07 12:08:40', 'balramsuman1470@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `status` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `status`) VALUES
(1, 'Land', 1),
(2, 'Commercial', 1),
(3, 'Flats', 1),
(4, 'Villa', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(6) NOT NULL,
  `city_name` varchar(255) NOT NULL,
  `state_id` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `city_name`, `state_id`) VALUES
(1, 'Kota\r\n', 1),
(2, 'Bundi', 1),
(3, 'Surat', 2),
(4, 'Ahemdabad', 2),
(5, 'Las vegas', 3),
(6, 'California', 3),
(7, 'Nakasaki', 4),
(8, 'Hiroshima', 4),
(9, 'Tokyo', 5),
(10, 'Xijioca', 5);

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `country_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_name`) VALUES
(1, 'India'),
(2, 'America\r\n'),
(3, 'Japan\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `purpose`
--

CREATE TABLE `purpose` (
  `id` int(11) NOT NULL,
  `purpose_name` varchar(50) NOT NULL,
  `status` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purpose`
--

INSERT INTO `purpose` (`id`, `purpose_name`, `status`) VALUES
(1, 'Rent', 1),
(2, 'Sell', 0),
(3, 'Rent & Sell', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sellertable`
--

CREATE TABLE `sellertable` (
  `id` int(20) NOT NULL,
  `property_image` varchar(255) NOT NULL,
  `agent_name` varchar(50) NOT NULL,
  `property_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `purpose` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` int(6) NOT NULL,
  `date-time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sellertable`
--

INSERT INTO `sellertable` (`id`, `property_image`, `agent_name`, `property_name`, `email`, `address`, `country`, `state`, `city`, `category`, `purpose`, `price`, `description`, `status`, `date-time`) VALUES
(2, '1674019750-download1.jpg', 'Balram suman', 'Suman Banglow', 'balramsuman1470@gmail.com', 'Borkheda', 'India', 'Rajasthan', 'Kota ', 'Commercial', 'Sell', '3000$', '3 BHK', 0, '2023-01-18 10:59:10'),
(3, '1674022477-images.jpg', 'Satya prakash', 'Prakash Villa', 'satyaprakash1470@gmail.com', 'Veersawarkar nagar', 'India', 'Rajasthan', 'Kota ', 'Land', 'Rent', '2500$', '3 BHK', 0, '2023-01-18 11:44:37'),
(4, '1674190890-images1.jpg', 'Dheeraj suman', 'Suman House', 'dheerajsuman1470@gmail.com', 'Vigyan nagar', 'India', 'Rajasthan', 'Kota ', 'Flat', 'Sell', '1999$', '3 BHK', 0, '2023-01-20 10:31:30'),
(6, '1674289464-istock.jpg', 'Anil Sharma', 'Sharmas Villa', 'anilsharma1470@gmail.com', 'Station main road', 'India', 'Rajasthan', 'Kota ', 'Villa', 'Sell & Rent', '4000$', '3 BHK', 0, '2023-01-20 13:06:15'),
(8, '1674279464-images1.jpg', 'Anil Sharma', 'Sharmas Villa', 'anilsharma1470@gmail.com', 'Naya Nohra, Baran Road', 'India', 'Rajasthan', 'Kota ', 'Villa', 'Sell & Rent', '3000$', '3 BHK', 0, '2023-01-21 11:07:44'),
(9, '1675081035-download.jpg', 'Anil Sharma', 'Sharma Property', 'anilsharma1470@gmail.com', 'Gandhi Nagar ', 'India', 'Rajasthan', 'Kota', 'Villa', 'Rent & Sell', '1999$', 'Property is any item that a person or a business has legal title over. Property can be tangible items, such as houses, cars, or appliances, or it can refer to intangible items that carry the promise of future worth, such as stock and bond certificates.', 0, '2023-01-30 17:47:15'),
(11, '1675081196-download.jpg', 'Anil Sharma', 'Sharma Property', 'anilsharma1470@gmail.com', 'Veersawarkar nagar', 'India', 'Rajasthan', 'Kota', 'Commercial', 'Rent & Sell', '3000$', 'Property is any item that a person or a business has legal title over. Property can be tangible items, such as houses, cars, or appliances, or it can refer to intangible items that carry the promise of future worth, such as stock and bond certificates.', 0, '2023-01-30 17:49:56'),
(12, '1675081378-download.jpg', 'Anil Sharma', 'Sharmas Villa', 'anilsharma1470@gmail.com', 'Station main road', 'India', 'Rajasthan', 'Kota', 'Land', 'Rent', '1999$', 'Property is any item that a person or a business has legal title over. Property can be tangible items, such as houses, cars, or appliances, or it can refer to intangible items that carry the promise of future worth, such as stock and bond certificates.', 1, '2023-01-30 17:52:58'),
(14, '1675141186-istock.jpg', 'Chetan suman', 'Suman Property', 'chetansuman1470@gmail.com', 'Shreenathpuram', 'India', 'Rajasthan', 'Kota', 'Villa', 'Rent & Sell', '2999$', 'This is very beautiful . It has maximum size.  In front of this a big garden is available. 5 rooms 2 kitchens and 3 bathrooms are available in this  villa. ', 0, '2023-01-31 10:29:46'),
(15, '1675144130-images.jpg', 'Chetan suman', 'Suman Property', 'chetansuman1470@gmail.com', 'R.K. Puram', 'Countries', 'States', 'Cities', 'Categories', 'Purpose', '1999$', '5BHK', 0, '2023-01-31 11:18:50'),
(16, '1675149547-images.jpg', 'Anil Sharma', 'Sharmas Villa', 'anilsharma1470@gmail.com', 'Station road', 'India', 'Rajasthan', 'Kota', 'Villa', 'Sell', '2999$', '3 BHK', 0, '2023-01-31 12:49:07'),
(17, '1675149703-download.jpg', 'Anil Sharma', 'Sharma Property', 'anilsharma1470@gmail.com', 'Station main road', 'India', 'Rajasthan', 'Kota', 'Villa', 'Sell', '3000$', 'drfyfdtjk', 1, '2023-01-31 12:51:43'),
(19, '1675230600-download.jpg', 'Ronak Dadhich', 'Dadhich Property', 'ronakdadhich@gmail.com', 'R.K. Puram', 'India', 'Rajasthan', 'Kota', 'Flats', 'Sell', '1999$', 'This is 3BHK flat.', 1, '2023-02-01 11:20:00');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(6) NOT NULL,
  `state_name` varchar(255) NOT NULL,
  `country_id` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `state_name`, `country_id`) VALUES
(1, 'Rajasthan', 1),
(2, 'Gujrat', 1),
(3, 'Washingoton', 2),
(4, 'Chong ching', 3),
(5, 'Chiang', 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(8) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `roles` varchar(20) NOT NULL,
  `timing` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `roles`, `timing`) VALUES
(1, 'Chetan suman', 'admin@gmail.com', '$2y$10$RPgEA2f4vQQ1ss1HuyXoMOlWex135mn8Cnk.aBrJIfwKvX4jq3S/K', 'Admin', '2023-01-10 11:33:35'),
(2, 'Anil sharma', 'anilsharma1470@gmail.com', '$2y$10$RPgEA2f4vQQ1ss1HuyXoMOlWex135mn8Cnk.aBrJIfwKvX4jq3S/K', 'Seller', '2023-01-11 12:00:51'),
(3, 'Himanshu saroya', 'himanshusaroya1470@gmail.com', '$2y$10$RPgEA2f4vQQ1ss1HuyXoMOlWex135mn8Cnk.aBrJIfwKvX4jq3S/K', 'Buyer', '2023-01-11 12:12:56'),
(6, 'Satyaprakash', 'satyaprakash1470@gmail.com', '$2y$10$RPgEA2f4vQQ1ss1HuyXoMOlWex135mn8Cnk.aBrJIfwKvX4jq3S/K', 'Seller', '2023-01-20 13:24:41'),
(7, 'Tarun suman', 'tannusuman1470@gmail.com', '$2y$10$rbeiBGvfmfSL.d1bREzwj.GAObISpc472nYWlPgTx.kq7VosZ5kVq', 'Buyer', '2023-01-21 10:15:20'),
(8, 'Chetan suman', 'chetansuman1470@gmail.com', '$2y$10$RPgEA2f4vQQ1ss1HuyXoMOlWex135mn8Cnk.aBrJIfwKvX4jq3S/K', 'Seller', '2023-01-30 14:18:31'),
(9, 'Ronak dadhich', 'ronakdadhich@gmail.com', '$2y$10$RPgEA2f4vQQ1ss1HuyXoMOlWex135mn8Cnk.aBrJIfwKvX4jq3S/K', 'Seller', '2023-02-01 10:29:34'),
(12, 'Mahesh Dhakad', 'maheshdhakad1470@gmail.com', '$2y$10$SugJHDWkxPKEhSKclKfGo.iNr7NFA4KDftQKksR64C2g0rzV7ICeq', 'Buyer', '2023-02-07 12:09:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buyertable`
--
ALTER TABLE `buyertable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `purpose`
--
ALTER TABLE `purpose`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sellertable`
--
ALTER TABLE `sellertable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buyertable`
--
ALTER TABLE `buyertable`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `purpose`
--
ALTER TABLE `purpose`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sellertable`
--
ALTER TABLE `sellertable`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
