<?php 

$showAlert1 = false;
$showAlert2 = false;
$showAlert3 = false;
$showAlert4 = false;

$emailerr = $nameerr = $passworderr = $cpassworderr = $roleerr = "";
$name = $email = $password = $cpassword = $role = "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {
  require "partials/_dbconnect.php";

  if (empty($_POST["name"])) {
    $nameerr  = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    if (!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
      $nameerr  = "*Invalid name format";
    }
  }

  if (empty($_POST["email"])) {
    $emailerr  = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailerr  = "*Invalid email format";
    }
  }
  

  $password = $_POST["password"];

  $cpassword = $_POST["cpassword"];

  $role = $_POST['role'];

  $sqlvalid = "SELECT * FROM `users` WHERE email = '$email'";
  $result = mysqli_query($conn,$sqlvalid);
  $num = mysqli_num_rows($result);
  if ($num > 0) {
    $showAlert1 = true;
  }else{
    if ($email != "" && $password != "" && $cpassword != "" && $name != "") {
      if ($password == $cpassword) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (name,email,password,roles) VALUES ('$name','$email','$hash','$role')";
        $result = mysqli_query($conn,$sql);
        if ($result) {
          $showAlert2 = true;
        }
      }else{
        $showAlert3 = true;
      }
    }else{
      $showAlert4 = true;
    }
  }
}

function test_input($data)
{
  $data = trim($data);
  $data = stripcslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">

    <title>CSProperty-Real State Property Management</title>

    <style type="text/css">
      .header{
        padding: 10px 0;
      }
      .navbar-brand{
        font-weight: 800;
        font-size: 25px;
      }
      #carouselExampleIndicators{
        margin: 0 50px;
        border-radius: 20px;
        overflow: hidden;
      }
      .btn-top{
        border-radius: 20px;
        padding: 5px 20px;
        background: #e5edff;
        color: #00a7ff;
        border: none;
        margin-bottom: 20px !important;
      }
      .border{
        border-radius: 10px;
      }

      .img-fluid{
        height: 680px !important;
      }
      ul li{
        margin: 0 20px;
      }
      .footer{
        padding: 10px 0 5px 0;
        background-color: #f8f9fa;
      }
      #listing{
        padding: 100px 0;
      }
      #agent{
        padding: 100px 0;
        background-color: #f8f8f8;
      }
      .agent-img{
        border-radius: 50%;
        width: 150px;
        height: 150px;
        margin-top: 20px;
      }
      .card-text{
        font-size: 12px;
      }
      #about{
        padding: 100px 0;
      }
      .error{
        color: red;
      }
    </style>
  </head>
  <body>
    <div class="header">
      <div class="container">    
        <nav class="navbar navbar-expand-lg navbar-light bg-light py-2">
          <a class="navbar-brand" href="/real-estate-property-manager">CS-Property</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto">
              <li class="nav-item active">
                <a class="nav-link" href="/real-estate-property-manager">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#agent">Agents</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="listing.php">Listing</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#about">About</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#contact">Contact</a>
              </li>
            </ul>
            <div class="mx-2 row">
              <a class="btn btn-outline-dark mr-2" href="signup.php" >SignUp</a> 
              <a class="btn btn-outline-dark mr-2" href="login.php">LogIn</a> 
            </div>
          </div>
        </nav>
      </div>
    </div>

    <?php if ($showAlert1) {
      echo '<div class="alert alert-warning alert-dismissible fade show" role="alert" mb-0>
        <strong>Alert :</strong> Email Already Exist...!!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>';
    }
    ?>

    <?php if ($showAlert2) {
      echo '<div class="alert alert-success alert-dismissible fade show" role="alert" mb-0>
        <strong>Alert :</strong> Data Submited Successfully...!!
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>';
    }
    ?>

    <?php if ($showAlert3) {
      echo '<div class="alert alert-danger alert-dismissible fade show" role="alert" mb-0>
        <strong>Alert :</strong> Password must be same.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>';
    }
    ?>

    <?php if ($showAlert4) {
      echo '<div class="alert alert-primary alert-dismissible fade show" role="alert" mb-0>
        <strong>Alert :</strong> Input must be filled.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>';
    }
    ?>

    <section class="vh-100" style="background-color: #f8f8f8;">
      <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
          <div class="col col-xl-10">
            <div class="card" style="border-radius: 1rem;">
              <div class="row g-0">
                <div class="col-md-6 col-lg-5 d-none d-md-block">
                  <img src="https://source.unsplash.com/random/1800×2400/?property" 
                    alt="login form" class="img-fluid" style="border-radius: 1rem 0 0 1rem;" />
                </div>
                <div class="col-md-6 col-lg-7 d-flex align-items-center">
                  <div class="card-body p-2 p-lg-3 text-black">

                    <form action="signup.php" method="POST">

                      <!-- <div class="d-flex align-items-center mb-3 pb-1">
                        <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                        <span class="h1 fw-bold mb-0">CS Porperty</span>
                      </div> -->

                      <h5 class="fw-normal mb-3 pb-3" style="letter-spacing: 1px;">Sign into CS Property</h5>

                      <div class="form-outline mb-3">
                        <input type="name" id="name" class="form-control form-control-lg" name="name" />
                        <label class="form-label" for="name">Name</label><span class="error"> * <?php echo $nameerr; ?></span><br>
                      </div>

                      <div class="form-outline mb-3">
                        <input type="email" id="form2Example17" class="form-control form-control-lg" name="email" />
                        <label class="form-label" for="form2Example17">Email address</label><span class="error"> * <?php echo $emailerr; ?></span><br>
                      </div>

                      <div class="form-outline mb-3">
                        <input type="password" id="form2Example27" class="form-control form-control-lg" name="password" />
                        <label class="form-label" for="form2Example27">Password</label>
                      </div>

                      <div class="form-outline mb-3">
                        <input type="password" id="form2Example27" class="form-control form-control-lg" name="cpassword" />
                        <label class="form-label" for="form2Example27">Confirm Password</label>
                      </div>

                      <div class="form-outline mb-3">
                        <select id="form2Example27" class="form-control form-control-lg" name="role">
                          <option value="Seller">Seller</option>
                          <option value="Buyer">Buyer</option>
                        </select>
                        <label class="form-label" for="form2Example27">Role</label>
                      </div>

                      <div class="pt-1 mb-3">
                        <button class="btn btn-dark btn-lg btn-block" type="submit">SignUp</button>
                      </div>

                    </form>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

  </body>
</html>


