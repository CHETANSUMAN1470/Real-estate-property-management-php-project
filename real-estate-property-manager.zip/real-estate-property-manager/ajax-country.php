<?php

require "partials/_dbconnect.php";

$country = $_POST['country'];

$sql = "SELECT * FROM states WHERE country_id='$country'";

$result = mysqli_query($conn,$sql);
?> 
<option value="">Select State</option>
<?php
	while ($row = mysqli_fetch_array($result)) {
?>
<option value="<?php echo $row['id'];?>"><?php echo $row['state_name'];?></option>
	<?php	}
?>
