<?php 

session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true) {
  header("location: login.php"); 
  exit ;
}

?>

<?php 

require "partials/_dbconnect.php";

$id = $_GET['id'];

$sql = "UPDATE sellertable SET status='0' WHERE id='$id' "; 

$result = mysqli_query($conn,$sql);

if ($result) {
  header("location: adminlisting.php");
}


?>


