<?php 

require "_dbconnect.php";

$id = $_GET['id'];
 
$sql = "DELETE FROM `sellertable` WHERE id='$id'";
$result = mysqli_query($conn , $sql);
if ($result) {
	header("location: ../adminlisting.php");
}else{
	echo "Error";
}
