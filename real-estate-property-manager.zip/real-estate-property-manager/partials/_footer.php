<div class="footer text-center">
	<p class="text-center mb-0">&copy Copyright; <strong>CS Property.</strong> All Right Reserved. Designed by <a href="#">CHETAN SUMAN</a></p>
</div>