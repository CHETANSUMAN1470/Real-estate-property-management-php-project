    <?php
    
    require "partials/_dbconnect.php";

    $sql = "SELECT * FROM `sellertable` ORDER BY id DESC LIMIT 1,3";
    $result = mysqli_query($conn , $sql);
    $row = mysqli_num_rows($result);

    ?>

<div class="row text-left">
<?php
	  if ($row > 0) {
	  	while($x = mysqli_fetch_assoc($result)) {
        if($x['status'] == 0){
	  	echo '<div class="card col-4 my-3" style="width: 18rem;">
  <img src="partials/images/'.$x["property_image"].'" class="card-img-top" alt="..." height="200px">
  <div class="card-body">
    <h5 class="card-title">'.$x["property_name"].'</h5>
    <p class="card-text">'.$x["address"].', '.$x["city"].', '.$x["state"].', '.$x["country"].'</p>
    <a href="propertydetails.php?id='.$x["id"].'" class="btn btn-primary">View Details</a>
  </div>
</div>';
        }
	  	}
	  } 
?>
</div>      
