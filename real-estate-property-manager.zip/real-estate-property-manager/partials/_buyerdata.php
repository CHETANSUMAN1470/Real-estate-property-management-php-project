<?php 

require "_dbconnect.php";

$sql = "SELECT * FROM `buyertable`";
$result = mysqli_query($conn , $sql);
$num = mysqli_num_rows($result);

?>

<table class="table table-striped" id="table_id">

<?php
	  echo "<thead class='thead-dark'>";
	  echo "<tr>";
	  echo "<th class='text-primary' scope='col'>S.No.</th>";
	  echo "<th class='text-primary' scope='col'>Name</th>";
	  echo "<th class='text-primary' scope='col'>Mobile No.</th>";
	  echo "<th class='text-primary' scope='col'>Email</th>";
	  echo "<th class='text-primary' scope='col'>Description</th>";
	  echo "<th class='text-primary' scope='col'>property Name</th>";	  
	  echo "<th class='text-primary' scope='col'>Action</th>";
	  echo "</tr>";
	  echo "</thead>";
	  echo "<tbody>";

	  $n = 1;

	  if ($num > 0) {
	  	while ($row = mysqli_fetch_assoc($result)) {
	  		echo "<tr>";
	  		echo "<th scope='row'>".$n."</th>";
	  		echo "<td>".$row['name']."</td>";
	  		echo "<td>".$row['mobile']."</td>";
	  		echo "<td>".$row['email']."</td>";
	  		echo "<td>".$row['description']."</td>";
	  		echo "<td>".$row['property_name']."</td>";
	  		echo "<td><a href='partials/_delete.php?id=" .$row["id"]."'><i class='bi bi-trash3'></i></a></td>";
	  		echo "</tr>";

	  		$n++;

	  	}
	  }
	  		echo "</tbody>";
?>

</table>
