<?php 

require "_dbconnect.php";
    $email = $_SESSION['email'];
    $sql = "SELECT * FROM `sellertable` WHERE email='$email'";
    $result = mysqli_query($conn,$sql);
    $num = mysqli_num_rows($result);


?>

<table class="table table-striped" id="table_id">

<?php
    echo "<thead class='thead-dark'>";
    echo "<tr>";
    echo "<th class='text-primary' scope='col'>S.No.</th>";
    echo "<th class='text-primary' scope='col'>Address</th>";
    echo "<th class='text-primary' scope='col'>Agent</th>";
    echo "<th class='text-primary' scope='col'>Property Name</th>";
    echo "<th class='text-primary' scope='col'>Categories</th>";
    echo "<th class='text-primary' scope='col'>Purpose</th>";
    echo "<th class='text-primary' scope='col'>price</th>";
    echo "<th class='text-primary' scope='col'>Preview</th>";
    echo "<th class='text-primary' scope='col'>Action</th>";
    echo "</tr>";
    echo "</thead>";
        echo "<tbody>";

    $n = 1;
    if ($num > 0) {
      while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<th scope='row'>".$n."</th>";
        echo "<td>".$row['address']."</td>";
        echo "<td>".$row['agent_name']."</td>";
        echo "<td>".$row['property_name']."</td>";
        echo "<td>".$row['category']."</td>";
        echo "<td>".$row['purpose']."</td>";
        echo "<td>".$row['price']."</td>";
        echo "<td><a href='propertydetails.php?id=".$row['id']."' class='btn btn-primary'>View details</a></td>";
        echo "<td><a href='listingupdate.php?id=".$row["id"]."'><i class='bi bi-pencil-square mr-2'></i></a>
              <a href='partials/_sellerlistingdelete.php?id=" .$row["id"]."'><i class='bi bi-trash3'></i></a></td>";
        echo "</tr>";

        $n++;

      }
    }
        echo "</tbody>";
?>

</table>
