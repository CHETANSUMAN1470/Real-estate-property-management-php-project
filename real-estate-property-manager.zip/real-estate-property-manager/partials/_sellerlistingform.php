<?php

$showAlert = false;
$showError = false;

$propertynameerr = $addresserr =  $countryerr = $stateerr = $cityerr = $categoryerr = $purposeerr = $priceerr = "";
$propertyname = $address = $country = $state = $city = $category = $purpose = $price = "";
 
if ($_SERVER['REQUEST_METHOD'] == "POST") {
  require "partials/_dbconnect.php";
  
  $agentname = $_POST['agent'];

  if (empty($_POST["property"])) {
    $propertynameerr = "Property Name is required";
  } else {
    $propertyname = test_input($_POST["property"]);
    if (!preg_match("/^[a-zA-Z-' ]*$/", $propertyname)) {
      $propertynameerr = "*Only letters and white spaces allowed";
    }
  }

  $email = $_SESSION['email'];

  if (empty($_POST["address"])) {
    $addresserr = "Address is required";
  } else {
    $address = test_input($_POST["address"]);
    if (!preg_match("/[A-Za-z0-9\-\\,.]+/", $address)) {
      $addresserr = "Only letters and white spaces allowed";
    }
  }

  if (empty($_POST["country"])) {
    $countryerr = "Country is required";
  } else {
    $country = test_input($_POST["country"]);
    if (!preg_match("/[A-Za-z0-9\-\\,.]+/", $country)) {
      $countryerr = "Only letters and white spaces allowed";
    }
  }

  if (empty($_POST["state"])) {
    $stateerr = "State is required";
  } else {
    $state = test_input($_POST["state"]);
    if (!preg_match("/[A-Za-z0-9\-\\,.]+/", $state)) {
      $stateerr = "Only letters and white spaces allowed";
    }
  }

  if (empty($_POST["city"])) {
    $cityerr = "City is required";
  } else {
    $city = test_input($_POST["city"]);
    if (!preg_match("/[A-Za-z0-9\-\\,.]+/", $city)) {
      $cityerr = "Only letters and white spaces allowed";
    }
  }

  if (empty($_POST["category"])) {
    $categoryerr = "Category is required";
  } else {
    $category = test_input($_POST["category"]);
    if (!preg_match("/[A-Za-z0-9\-\\,.]+/", $category)) {
      $categoryerr = "Only letters and white spaces allowed";
    }
  }

  if (empty($_POST["purpose"])) {
    $purposeerr = "Purpose is required";
  } else {
    $purpose = test_input($_POST["purpose"]);
    if (!preg_match("/[A-Za-z0-9\-\\,.]+/", $purpose)) {
      $purposeerr = "*Only letters and white spaces allowed";
    }
  }

  if (empty($_POST["price"])) {
    $priceerr = "Price is required";
  } else {
    $price = test_input($_POST["price"]);
    if (!preg_match("/[A-Za-z0-9\-\\,.]+/", $price)) {
      $priceerr = "*Only letters and white spaces allowed";
    }
  }

  $description = $_POST['description'];

  if (isset($_FILES['image'])) {
    $errors = array();

    $filename = $_FILES['image']['name'];
    $filesize = $_FILES['image']['size']; 
    $filetmp = $_FILES['image']['tmp_name']; 
    $filetype = $_FILES['image']['type']; 

    $exp = explode(".", $filename);
    $file_ext = end($exp);

    $extentions = array("jpg" ,"png" ,"jpeg");

    if (in_array($file_ext, $extentions) === false) {
      $errors[] = "Please choose jpg and png file.";
    } 
    
    if ($filesize > 2097152) {
      $errors[] = "File size should be 2MB."; 
    }

    $new_name = time()."-".basename($filename);
    $target = "partials/images/".$new_name ;

    if (empty($errors) == true) {
      move_uploaded_file($filetmp, $target);
    }else{
      $showAlertImage = $errors;
    }
  }

  if ($propertyname != "" && $address != "" && $country != "" && $state != "" && $city != "" && $category != "" && $purpose != "" && $price != "" && $description != "" && $new_name != "") {
    
    $sql = "INSERT INTO `sellertable` (`property_image`,`agent_name`,`property_name`, `email`,`address`,`country`,`state`,`city`,`category`,`purpose`,`price`,`description`,`status`) VALUES ('$new_name','$agentname','$propertyname', '$email','$address','$country','$state','$city','$category','$purpose','$price','$description','1')";

    $result = mysqli_query($conn,$sql);

    if ($result) {
      $showAlert = true;
    }else{
      $showError = true;
    }

  }
}

function test_input($data)
{
  $data = trim($data);
  $data = stripcslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>

<body>
  <?php if ($showAlert) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Alert !</strong> Data submited successfully...!!
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';}
?>
<?php if ($showError) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Alert !</strong> Data submited successfully...!!
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';}
?>

      <!-- <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center"> -->
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-10 col-md-10 d-flex flex-column align-items-center justify-content-center">

              <div class="d-flex justify-content-center py-4">
                <a href="index.html" class="logo d-flex align-items-center w-auto">
                  <img src="assets/img/logo.png" alt="">
                  <span class="d-none d-lg-block">CS Property Register Form</span>
                </a>
              </div><!-- End Logo -->

              <div class="card mb-3">

                <div class="card-body">

                  <form class="row g-3 mt-1 needs-validation" action="sellerlisting.php" method="POST" enctype="multipart/form-data">

                    <div class="col-6">
                      <label class="form-label">Property Image</label>
                      <input type="file" name="image" class="form-control" >
                    </div>

                    <?php 
                    $email = $_SESSION['email'];
                    $sql = "SELECT * FROM users WHERE email='$email'";
                    $result = mysqli_query($conn,$sql);
                    $row = mysqli_fetch_assoc($result);
                    ?>

                    <div class="col-6">
                      <label class="form-label">Agent Name</label>
                      <input type="text" name="agent" class="form-control" readonly value="<?php echo $row['name']; ?>">
                    </div>

                    <div class="col-12">
                      <label class="form-label">Property Name</label><span class="error"> * <?php echo $propertynameerr; ?></span><br>
                      <input type="text" name="property" class="form-control"  >
                    </div>

                    <div class="col-12">
                      <label class="form-label">Email</label>
                      <input type="email" name="email" disabled class="form-control" value="<?php echo $_SESSION['email']; ?>">
                    </div>

                    <div class="col-12">
                      <label class="form-label">Address</label><span class="error"> * <?php echo $addresserr; ?></span><br>
                      <input type="text" name="address" class="form-control">
                    </div>

                    <?php
                    $sql = "SELECT * FROM countries";
                    $result = mysqli_query($conn,$sql);
                    $num = mysqli_num_rows($result);
                    ?>

                    <div class="col-4">
                      <label class="form-label">Countries</label><span class="error"> * <?php echo $countryerr; ?></span><br>
                      <select type="text" id="country" name="country" class="form-control" readonly>
                        <option value="">Countries</option>
                        <?php
                         while ($row = mysqli_fetch_assoc($result)) {
                          echo '<option value="'.$row['id'].'">'.$row['country_name'].'</option>';
                        }?>
                      </select>
                    </div>

                    <div class="col-4">
                      <label class="form-label">State</label><span class="error"> * <?php echo $stateerr; ?></span><br>
                      <select type="text" id="region" name="state" class="form-control" readonly>
                        <option value="">States</option>
                      </select>
                    </div>

                    <div class="col-4">
                      <label class="form-label">City</label><span class="error"> * <?php echo $cityerr; ?></span><br>
                      <select type="text" id="city" name="city" class="form-control" readonly>
                      <option value="">Cities</option>
                      </select>
                    </div>

                    <div id="location"></div>

                    <?php
                    $sql = "SELECT * FROM categories";
                    $result = mysqli_query($conn,$sql);
                    $num = mysqli_num_rows($result);
                    ?>

                    <div class="col-4">
                      <label class="form-label">Category</label><span class="error"> * <?php echo $categoryerr; ?></span><br>
                      <select type="text" name="category" class="form-control" readonly>
                        <option value="">Categories</option>
                        <?php 
                         while ($row = mysqli_fetch_assoc($result)) {
                          if ($row['status'] == 1) {
                            echo '<option>'.$row['category_name'].'</option>';
                          }
                        }?>
                      </select>
                    </div>

                    <?php
                    $sql = "SELECT * FROM purpose";
                    $result = mysqli_query($conn,$sql);
                    $num = mysqli_num_rows($result);
                    ?>

                    <div class="col-4">
                      <label class="form-label">Purpose</label><span class="error"> * <?php echo $purposeerr; ?></span><br>
                      <select type="text" name="purpose" class="form-control" readonly>
                      <option value="">Purpose</option>
                      <?php
                        while ($row = mysqli_fetch_assoc($result)) {
                        if ($row['status'] == 1) {
                            echo '<option>'.$row['purpose_name'].'</option>';
                          }
                      }?>
                      </select>
                    </div>

                    <div class="col-4">
                      <label class="form-label">Price</label><span class="error"> * <?php echo $priceerr; ?></span><br>
                      <input type="text" name="price" class="form-control" >
                    </div>

                    <div class="col-12">
                      <label class="form-label">Description</label>
                      <textarea type="text" name="description" class="form-control" ></textarea>
                    </div>

                    <div class="col-12">
                      <button class="btn btn-primary w-100" type="submit">Listing</button>
                    </div>
                  </form>

                </div>
              </div>

            </div>
          </div>
        </div>


