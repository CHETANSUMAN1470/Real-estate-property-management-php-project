<?php 

require "_dbconnect.php";

$id = $_GET['id'];
 
$sql = "DELETE FROM `buyertable` WHERE id='$id'";
$result = mysqli_query($conn , $sql);
if ($result) {
	header("location: ../buyerinquiry.php");
}else{
	echo "Error";
}
